peliculas = {
    'P101': ['Luz de Otoño', 'drama', 110, 'B', 'Español', False],
    'P102': ['Noche Neón', 'acción', 125, 'C', 'Ingles', True],
    'P103': ['Planeta Agua', 'documental', 90, 'A', 'Español', False],
    'P104': ['Risa Total', 'comedia', 105, 'A', 'Español', True],
    'P105': ['Código Zero', 'thriller', 118, 'C', 'Ingles', True],
    'P106': ['Viaje Lunar', 'ciencia ficción', 132, 'B', 'Ingles', False],
}

cartelera = {
    'P101': [5990, 40],
    'P102': [7990, 0],
    'P103': [4990, 25],
    'P104': [6990, 12],
    'P105': [8990, 8],
    'P106': [7490, 3],
}

def leer_opcion() -> int:
    
    while True:
        try:
            opcion_ingresada = input("Ingrese opción: ")
            opcion = int(opcion_ingresada)
            if 1 <= opcion <= 6:
                return opcion
            else:
                print("Debe seleccionar una opción válida")
        except ValueError:
            print("Debe seleccionar una opción válida")

def buscar_codigo(cartelera: dict, codigo: str) -> bool:
    
    codigo_upper = codigo.upper()
    for clave in cartelera.keys():
        if clave.upper() == codigo_upper:
            return True
    return False

def busqueda_genero(peliculas,cartelera, genero):
    
    genero_buscado = genero.strip().lower()
    total_cupos = 0

    for codigo, datos in peliculas.items():
        genero_pelicula = datos[1].lower()
        if genero_pelicula == genero_buscado:
            if codigo in cartelera:
                total_cupos += cartelera[codigo][1]

    print(f"El total de cupos disponibles es: {total_cupos}")

def búsqueda_precio(p_min, p_max):
   
    resultados = []
    
    for codigo, datos in cartelera.items():
        precio = datos[0]
        cantidad_stock = datos[1]
        
        
        if p_min <= precio <= p_max and cantidad_stock > 0:
            
            if codigo in peliculas:
                titulo = peliculas[codigo][0]
                resultados.append(f"{titulo}--{codigo}")
                
    if len(resultados) > 0:
        
        resultados.sort()
        print(f"Las películas encontradas son:: {resultados}")
    else:
        print("No hay películas en ese rango de precios")


def actualizar_precio(codigo, p):
   
    if codigo in cartelera:
        cartelera[codigo][0] = p
        return True
    return False

def validar_codigo(codigo, cartelera) -> bool:
    
    codigo_limpio = codigo.strip()
    if not codigo_limpio:
        return False
    
    codigo_upper = codigo_limpio.upper()
    for clave in cartelera.keys():
        if clave.upper() == codigo_upper:
            return False
    return True


def validar_titulo(titulo) -> bool:
    
    return bool(titulo.strip())


def validar_genero(genero) -> bool:
    
    return bool(genero.strip())


def validar_duracion(duracion) -> bool:
    
    return duracion > 0


def validar_clasificacion(clasificacion) -> bool:
    
    return clasificacion in ['A', 'B', 'C']


def validar_idioma(idioma) -> bool:
    
    return bool(idioma.strip())


def validar_es_3d(es_3d_input) -> bool:
    
    return es_3d_input in ['s', 'n']


def validar_precio(precio) -> bool:
    
    return precio > 0


def validar_cupos(cupos) -> bool:
    
    return cupos >= 0

def agregar_pelicula(peliculas, cartelera, codigo, titulo, 
                     genero, duracion, clasificacion, idioma, 
                     es_3d, precio, cupos) -> bool:
    
    codigo_final = codigo.strip().upper()
    
    if buscar_codigo(cartelera, codigo_final):
        return False
    
    peliculas[codigo_final] = [titulo.strip(), genero.strip(), duracion, 
                               clasificacion, idioma.strip(), es_3d]
    cartelera[codigo_final] = [precio, cupos]
    
    return True

def obtener_clave_real(cartelera, codigo) -> str:
    
    codigo_upper = codigo.upper()
    for clave in cartelera.keys():
        if clave.upper() == codigo_upper:
            return clave
    return codigo

def eliminar_pelicula(peliculas, cartelera, codigo) -> bool:
    
    if buscar_codigo(cartelera, codigo):
        clave_real = obtener_clave_real(cartelera, codigo)
        peliculas.pop(clave_real)
        cartelera.pop(clave_real)
        return True
    return False

def main():

    while True:
        print("\n========== MENÚ PRINCIPAL ==========")
        print("1. Cupos por género")
        print("2. Búsqueda de películas por rango de precio")
        print("3. Actualizar precio de película")
        print("4. Agregar película")
        print("5. Eliminar película")
        print("6. Salir")
        
        opcion = leer_opcion()
        
        if opcion == 1:
            genero = input("Ingrese un género a consultar: ")
            busqueda_genero(peliculas, cartelera, genero)
            
        elif opcion == 2:
            
            while True:
                try:
                    p_min = int(input("Ingrese precio mínimo: "))
                    p_max = int(input("Ingrese precio máximo: "))
                    break  
                except ValueError:
                    print("Debe ingresar valores enteros!!\n")
                    
            búsqueda_precio(p_min, p_max)
            
        elif opcion == 3:
            while True:
                cod_input = input("Ingrese codigo de pelicula a actualizar: ").strip()
                
                while True:
                    try:
                        precio_nuevo = int(input("Ingrese precio nuevo: "))
                        break
                    except ValueError:
                        print("Debe ingresar un valor entero para el precio")
                
                
                if actualizar_precio(cod_input, precio_nuevo):
                    print("Precio actualizado")
                else:
                    print("El código no existe")
                
                
                continuar = input("\nDesea actualizar otro precio (s/n)?: ").strip().lower()
                if continuar != "s":
                    break
                    
        elif opcion == 4:
            
            codigo = input("Ingrese código de película: ")
            if not validar_codigo(codigo, cartelera):
                print("Error: El código no puede estar vacío o ya existe en el sistema")
                continue
            
            titulo = input("Ingrese título: ")
            if not validar_titulo(titulo):
                print("Error: El título no debe estar vacío")
                continue

            genero = input("Ingrese género: ")
            if not validar_genero(genero):
                print("Error: El género no debe estar vacío")
                continue

            try:
                duracion = int(input("Ingrese duración (minutos): "))
                if not validar_duracion(duracion):
                    print("Error: La duración debe ser mayor que cero")
                    continue
            except ValueError:
                print("Error: Debe ingresar un entero válido")
                continue

            clasificacion = input("Ingrese clasificación: ").strip().upper()
            if not validar_clasificacion(clasificacion):
                print("Error: Debe ser 'A', 'B' o 'C'")
                continue

            idioma = input("Ingrese idioma: ")
            if not validar_idioma(idioma):
                print("Error: El idioma no debe estar vacío")
                continue
            
            es_3d_input = input("¿Es 3D? (s/n): ").strip().lower()
            if not validar_es_3d(es_3d_input):
                print("Error: Debe ser 's' o 'n'")
                continue
            es_3d = True if es_3d_input == 's' else False
            
            try:
                precio = int(input("Ingrese precio: "))
                if not validar_precio(precio):
                    print("Error: El precio debe ser mayor que cero")
                    continue
            except ValueError:
                print("Error: Debe ingresar un entero válido")
                continue

            try:
                cupos = int(input("Ingrese cupos: "))
                if not validar_cupos(cupos):
                    print("Error: Los cupos no pueden ser negativos")
                    continue
            except ValueError:
                print("Error: Debe ingresar un entero válido")
                continue

            if agregar_pelicula(peliculas, cartelera, codigo, titulo, genero, 
                               duracion, clasificacion, idioma, es_3d, precio, cupos):
                print("Película agregada")
            else:
                print("El código ya existe")

        elif opcion == 5:
            codigo = input("Ingrese el código de la película a eliminar: ")
            if eliminar_pelicula(peliculas, cartelera, codigo):
                print("Película eliminada")
            else:
                print("El código no existe")
                    
        elif opcion == 6:
            print("Programa finalizado.")
            break
            

if __name__ == "__main__":
    main()